package sg.meimei.websnap

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Captures one widget's page and pushes the result to the launcher, then
 * re-enqueues itself so the widget keeps refreshing on the user's interval.
 *
 * WorkManager is used rather than a Service because Android 8+ forbids
 * background service starts, and ColorOS is especially strict about them.
 */
class SnapWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val widgetId = inputData.getInt(KEY_WIDGET_ID, -1)
        if (widgetId == -1) return Result.failure()

        val ctx = applicationContext
        val url = Prefs.getUrl(ctx, widgetId) ?: return Result.failure()
        val mgr = AppWidgetManager.getInstance(ctx)

        val (w, h) = widgetPixelSize(ctx, mgr, widgetId)

        val bmp = WebSnapRenderer.render(
            ctx = ctx,
            url = url,
            widthPx = w,
            heightPx = h,
            zoomPercent = Prefs.getZoom(ctx, widgetId),
            scrollXPx = dp(ctx, Prefs.getScrollX(ctx, widgetId)),
            scrollYPx = dp(ctx, Prefs.getScrollY(ctx, widgetId)),
            desktopMode = Prefs.getDesktop(ctx, widgetId)
        )

        val views = RemoteViews(ctx.packageName, R.layout.widget_websnap)
        if (bmp != null) {
            views.setImageViewBitmap(R.id.widget_image, bmp)
            views.setViewVisibility(R.id.widget_status, View.GONE)
        } else {
            views.setViewVisibility(R.id.widget_status, View.VISIBLE)
            views.setTextViewText(R.id.widget_status, "Couldn't load page")
        }

        // Tapping the widget opens the live page in the browser.
        val open = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        views.setOnClickPendingIntent(
            R.id.widget_image,
            PendingIntent.getActivity(
                ctx, widgetId, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )

        mgr.updateAppWidget(widgetId, views)

        schedule(ctx, widgetId, Prefs.getIntervalMin(ctx, widgetId).toLong())
        return if (bmp != null) Result.success() else Result.retry()
    }

    private fun widgetPixelSize(
        ctx: Context,
        mgr: AppWidgetManager,
        id: Int
    ): Pair<Int, Int> {
        val opts = mgr.getAppWidgetOptions(id)
        // MAX_WIDTH / MIN_HEIGHT describe the widget in its current orientation,
        // which is what changes when the Find N5 is folded or unfolded.
        val wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 250)
        val hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 250)
        return Pair(
            dp(ctx, if (wDp > 0) wDp else 250),
            dp(ctx, if (hDp > 0) hDp else 250)
        )
    }

    private fun dp(ctx: Context, v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), ctx.resources.displayMetrics
    ).toInt()

    companion object {
        const val KEY_WIDGET_ID = "widget_id"

        fun tag(id: Int) = "websnap_$id"

        /** Enqueue a capture. delayMin = 0 runs as soon as the constraints allow. */
        fun schedule(ctx: Context, widgetId: Int, delayMin: Long) {
            val req = OneTimeWorkRequestBuilder<SnapWorker>()
                .setInputData(Data.Builder().putInt(KEY_WIDGET_ID, widgetId).build())
                .setInitialDelay(delayMin.coerceAtLeast(0L), TimeUnit.MINUTES)
                .addTag(tag(widgetId))
                .build()
            WorkManager.getInstance(ctx)
                .enqueueUniqueWork(tag(widgetId), ExistingWorkPolicy.REPLACE, req)
        }

        fun cancel(ctx: Context, widgetId: Int) {
            WorkManager.getInstance(ctx).cancelUniqueWork(tag(widgetId))
        }
    }
}

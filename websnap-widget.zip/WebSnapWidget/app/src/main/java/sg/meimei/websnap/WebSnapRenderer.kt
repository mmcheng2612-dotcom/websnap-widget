package sg.meimei.websnap

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Build
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine
import kotlin.math.sqrt

/**
 * Renders a web page offscreen into a Bitmap sized for a home-screen widget.
 *
 * Runs entirely on the main thread because WebView requires it. The WebView is
 * never attached to a window; it is measured and laid out manually, then drawn
 * straight onto a Canvas.
 */
object WebSnapRenderer {

    /**
     * RemoteViews are delivered across a Binder transaction with a hard ~1MB
     * ceiling. Staying under ~1.1M pixel-bytes leaves headroom for the rest of
     * the RemoteViews payload.
     */
    private const val MAX_BITMAP_BYTES = 1_100_000


    suspend fun render(
        ctx: Context,
        url: String,
        widthPx: Int,
        heightPx: Int,
        zoomPercent: Int,
        scrollXPx: Int,
        scrollYPx: Int,
        desktopMode: Boolean,
        settleMs: Long = 1500L,
        timeoutMs: Long = 30_000L
    ): Bitmap? = withContext(Dispatchers.Main) {
        if (widthPx <= 0 || heightPx <= 0) return@withContext null

        val web = WebView(ctx.applicationContext)
        try {
            // Inherit the session established by LoginActivity. CookieManager is
            // process-wide, so any cookie set during login is visible here.
            val cookies = android.webkit.CookieManager.getInstance()
            cookies.setAcceptCookie(true)
            cookies.setAcceptThirdPartyCookies(web, true)

            web.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                loadWithOverviewMode = true
                useWideViewPort = desktopMode
                blockNetworkImage = false
                if (desktopMode) userAgentString = UserAgents.DESKTOP
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                web.settings.safeBrowsingEnabled = false
            }
            web.setInitialScale(zoomPercent.coerceIn(25, 400))
            web.setBackgroundColor(Color.WHITE)
            web.isVerticalScrollBarEnabled = false
            web.isHorizontalScrollBarEnabled = false

            // Manual measure/layout: the view has no parent, so nothing else will size it.
            web.measure(
                View.MeasureSpec.makeMeasureSpec(widthPx, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(heightPx, View.MeasureSpec.EXACTLY)
            )
            web.layout(0, 0, widthPx, heightPx)

            val loaded = withTimeoutOrNull(timeoutMs) {
                suspendCoroutine { cont ->
                    var resumed = false
                    web.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, u: String?) {
                            if (!resumed) { resumed = true; cont.resume(true) }
                        }
                    }
                    web.loadUrl(url)
                }
            } ?: false

            if (!loaded) return@withContext null

            // Let late-arriving JS, fonts and images paint before capturing.
            kotlinx.coroutines.delay(settleMs)

            // Critical: the WebView re-measures itself once content loads, but with
            // no parent attached nothing performs that layout pass. Without forcing
            // it here, draw() uses the pre-load geometry and the page renders
            // offset down the canvas, leaving a blank band at the top.
            web.measure(
                View.MeasureSpec.makeMeasureSpec(widthPx, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(heightPx, View.MeasureSpec.EXACTLY)
            )
            web.layout(0, 0, widthPx, heightPx)

            web.scrollTo(scrollXPx.coerceAtLeast(0), scrollYPx.coerceAtLeast(0))

            // Give the compositor a frame to settle at the new geometry and
            // scroll position before we read pixels out of it.
            kotlinx.coroutines.delay(400L)

            val scale = downscaleFactor(widthPx, heightPx)
            val outW = (widthPx * scale).toInt().coerceAtLeast(1)
            val outH = (heightPx * scale).toInt().coerceAtLeast(1)

            val bmp = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            canvas.drawColor(Color.WHITE)
            if (scale != 1f) canvas.scale(scale, scale)
            web.draw(canvas)
            bmp
        } catch (t: Throwable) {
            null
        } finally {
            web.stopLoading()
            web.destroy()
        }
    }

    private fun downscaleFactor(w: Int, h: Int): Float {
        val bytes = w.toLong() * h.toLong() * 4L
        if (bytes <= MAX_BITMAP_BYTES) return 1f
        return sqrt(MAX_BITMAP_BYTES.toDouble() / bytes.toDouble()).toFloat()
    }
}

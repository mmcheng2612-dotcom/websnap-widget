package sg.meimei.websnap

/**
 * The login WebView and the capture WebView must present the SAME user agent.
 * Many session cookies are bound to the UA that created them; if they differ,
 * the server hands back a login page even though the cookie is valid.
 */
object UserAgents {
    const val DESKTOP =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Safari/537.36"
}

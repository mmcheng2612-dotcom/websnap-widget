package sg.meimei.websnap

import android.content.Context

/** Per-widget settings, keyed by AppWidget ID. */
object Prefs {
    private const val FILE = "websnap_prefs"

    private fun sp(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun setUrl(ctx: Context, id: Int, v: String) = sp(ctx).edit().putString("url_$id", v).apply()
    fun getUrl(ctx: Context, id: Int): String? = sp(ctx).getString("url_$id", null)

    fun setZoom(ctx: Context, id: Int, v: Int) = sp(ctx).edit().putInt("zoom_$id", v).apply()
    fun getZoom(ctx: Context, id: Int): Int = sp(ctx).getInt("zoom_$id", 100)

    fun setScrollX(ctx: Context, id: Int, v: Int) = sp(ctx).edit().putInt("sx_$id", v).apply()
    fun getScrollX(ctx: Context, id: Int): Int = sp(ctx).getInt("sx_$id", 0)

    fun setScrollY(ctx: Context, id: Int, v: Int) = sp(ctx).edit().putInt("sy_$id", v).apply()
    fun getScrollY(ctx: Context, id: Int): Int = sp(ctx).getInt("sy_$id", 0)

    fun setIntervalMin(ctx: Context, id: Int, v: Int) = sp(ctx).edit().putInt("iv_$id", v).apply()
    fun getIntervalMin(ctx: Context, id: Int): Int = sp(ctx).getInt("iv_$id", 30)

    fun setDesktop(ctx: Context, id: Int, v: Boolean) = sp(ctx).edit().putBoolean("dk_$id", v).apply()
    fun getDesktop(ctx: Context, id: Int): Boolean = sp(ctx).getBoolean("dk_$id", false)

    fun clear(ctx: Context, id: Int) {
        sp(ctx).edit()
            .remove("url_$id").remove("zoom_$id").remove("sx_$id")
            .remove("sy_$id").remove("iv_$id").remove("dk_$id")
            .apply()
    }
}

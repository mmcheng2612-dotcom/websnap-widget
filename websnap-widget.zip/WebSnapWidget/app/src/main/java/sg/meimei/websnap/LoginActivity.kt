package sg.meimei.websnap

import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * A normal, visible browser window used once to establish a session.
 *
 * Cookies set here live in the app's process-wide CookieManager, so the
 * offscreen capture WebView inherits the login automatically. Nothing about
 * your credentials is stored by this app — only the site's own session cookie,
 * in Android's standard WebView cookie store.
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val urlBar = findViewById<EditText>(R.id.login_url)
        val go = findViewById<Button>(R.id.login_go)
        val done = findViewById<Button>(R.id.login_done)
        val logout = findViewById<Button>(R.id.login_logout)
        val progress = findViewById<ProgressBar>(R.id.login_progress)
        web = findViewById(R.id.login_web)

        // Persist cookies across app restarts.
        val cookies = CookieManager.getInstance()
        cookies.setAcceptCookie(true)
        cookies.setAcceptThirdPartyCookies(web, true)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = true
            displayZoomControls = false
            // Must match the capture WebView, or the session won't carry over.
            userAgentString = UserAgents.DESKTOP
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                progress.visibility = View.GONE
                CookieManager.getInstance().flush()
            }
        }
        web.webChromeClient = WebChromeClient()

        // Pre-fill with the URL of the widget that launched us, if any.
        intent.getStringExtra(EXTRA_URL)?.let { urlBar.setText(it) }

        go.setOnClickListener {
            var u = urlBar.text.toString().trim()
            if (u.isEmpty()) return@setOnClickListener
            if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://$u"
            progress.visibility = View.VISIBLE
            web.loadUrl(u)
        }

        done.setOnClickListener {
            CookieManager.getInstance().flush()
            Toast.makeText(this, "Session saved", Toast.LENGTH_SHORT).show()
            finish()
        }

        logout.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear session")
                .setMessage(
                    "This removes all cookies and cached pages held by this app. " +
                        "Widgets will show the login page again until you sign back in."
                )
                .setPositiveButton("Clear") { _, _ -> clearEverything() }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // Load straight away if we were handed a URL.
        intent.getStringExtra(EXTRA_URL)?.let { go.performClick() }
    }

    private fun clearEverything() {
        val cookies = CookieManager.getInstance()
        cookies.removeAllCookies { cookies.flush() }
        web.clearCache(true)
        web.clearHistory()
        web.clearFormData()
        android.webkit.WebStorage.getInstance().deleteAllData()
        Toast.makeText(this, "Session cleared", Toast.LENGTH_SHORT).show()
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    companion object {
        const val EXTRA_URL = "url"
    }
}

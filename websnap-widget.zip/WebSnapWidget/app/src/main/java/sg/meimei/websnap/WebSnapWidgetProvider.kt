package sg.meimei.websnap

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Bundle

class WebSnapWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { SnapWorker.schedule(ctx, it, 0) }
    }

    /**
     * Fired when the widget is resized — including the reflow that happens
     * every time a foldable is opened or closed. Re-capture at the new size so
     * the snapshot isn't stretched.
     */
    override fun onAppWidgetOptionsChanged(
        ctx: Context,
        mgr: AppWidgetManager,
        id: Int,
        newOptions: Bundle
    ) {
        SnapWorker.schedule(ctx, id, 0)
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        ids.forEach {
            SnapWorker.cancel(ctx, it)
            Prefs.clear(ctx, it)
        }
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action == ACTION_REFRESH) {
            val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1)
            if (id != -1) SnapWorker.schedule(ctx, id, 0)
        }
    }

    companion object {
        const val ACTION_REFRESH = "sg.meimei.websnap.ACTION_REFRESH"
    }
}

package sg.meimei.websnap

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle

class WebSnapWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { SnapWorker.schedule(ctx, it, 0) }
    }

    /**
     * Fired when the widget is resized — including the reflow that happens
     * every time a foldable is opened or closed. Re-capture at the new size so
     * the snapshot isn't stretched.
     */
    override fun onAppWidgetOptionsChanged(
        ctx: Context,
        mgr: AppWidgetManager,
        id: Int,
        newOptions: Bundle
    ) {
        SnapWorker.schedule(ctx, id, 0)
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        ids.forEach {
            SnapWorker.cancel(ctx, it)
            Prefs.clear(ctx, it)
        }
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1)
        if (id == -1) return

        when (intent.action) {
            ACTION_REFRESH -> SnapWorker.schedule(ctx, id, 0)

            ACTION_TAP -> {
                val privacyOn = Prefs.getPrivacy(ctx, id)
                if (privacyOn && !Prefs.isRevealed(ctx, id)) {
                    // First tap on a hidden tile: open the reveal window.
                    Prefs.setRevealedUntil(
                        ctx, id, System.currentTimeMillis() + REVEAL_MS
                    )
                    SnapWorker.schedule(ctx, id, 0)
                } else {
                    // Already visible: behave like a normal link.
                    Prefs.getUrl(ctx, id)?.let { url ->
                        ctx.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            }
        }
    }

    companion object {
        const val ACTION_REFRESH = "sg.meimei.websnap.ACTION_REFRESH"
        const val ACTION_TAP = "sg.meimei.websnap.ACTION_TAP"

        /** How long a revealed tile stays visible before blanking itself. */
        const val REVEAL_MS = 2 * 60 * 1000L
    }
}

package sg.meimei.websnap

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ConfigActivity : AppCompatActivity() {

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Assume cancellation: if the user backs out, no widget is placed.
        setResult(Activity.RESULT_CANCELED)
        setContentView(R.layout.activity_config)

        widgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }

        val urlField = findViewById<EditText>(R.id.edit_url)
        val zoomField = findViewById<EditText>(R.id.edit_zoom)
        val sxField = findViewById<EditText>(R.id.edit_sx)
        val syField = findViewById<EditText>(R.id.edit_sy)
        val ivField = findViewById<EditText>(R.id.edit_interval)
        val desktopBox = findViewById<CheckBox>(R.id.check_desktop)
        val privacyBox = findViewById<CheckBox>(R.id.check_privacy)

        // Pre-fill when re-configuring an existing widget.
        Prefs.getUrl(this, widgetId)?.let { urlField.setText(it) }
        zoomField.setText(Prefs.getZoom(this, widgetId).toString())
        sxField.setText(Prefs.getScrollX(this, widgetId).toString())
        syField.setText(Prefs.getScrollY(this, widgetId).toString())
        ivField.setText(Prefs.getIntervalMin(this, widgetId).toString())
        desktopBox.isChecked = Prefs.getDesktop(this, widgetId)
        privacyBox.isChecked = Prefs.getPrivacy(this, widgetId)

        // Opens a real browser window so the site can set its session cookie,
        // which the offscreen capture WebView then reuses.
        findViewById<Button>(R.id.btn_login).setOnClickListener {
            val u = urlField.text.toString().trim()
            startActivity(
                Intent(this, LoginActivity::class.java)
                    .putExtra(LoginActivity.EXTRA_URL, u)
            )
        }

        findViewById<Button>(R.id.btn_save).setOnClickListener {
            var url = urlField.text.toString().trim()
            if (url.isEmpty()) {
                Toast.makeText(this, "Enter a URL", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                url = "https://$url"
            }

            Prefs.setUrl(this, widgetId, url)
            Prefs.setZoom(this, widgetId, zoomField.text.toString().toIntOrNull() ?: 100)
            Prefs.setScrollX(this, widgetId, sxField.text.toString().toIntOrNull() ?: 0)
            Prefs.setScrollY(this, widgetId, syField.text.toString().toIntOrNull() ?: 0)
            Prefs.setIntervalMin(
                this, widgetId,
                (ivField.text.toString().toIntOrNull() ?: 30).coerceAtLeast(15)
            )
            Prefs.setDesktop(this, widgetId, desktopBox.isChecked)
            Prefs.setPrivacy(this, widgetId, privacyBox.isChecked)
            Prefs.setRevealedUntil(this, widgetId, 0L)

            SnapWorker.schedule(this, widgetId, 0)

            setResult(
                Activity.RESULT_OK,
                Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
            )
            finish()
        }
    }
}

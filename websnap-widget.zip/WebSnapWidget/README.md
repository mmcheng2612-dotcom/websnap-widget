# WebSnap Widget

A Widgetify-style Android home-screen widget: point it at a URL, and it renders
a live snapshot of that page onto your home screen, refreshing on a schedule.
Built and tested against the Oppo Find N5 (ColorOS 15 / Android 15), including
its fold/unfold resize behaviour.

## Getting an installable APK without a PC

1. Create a free GitHub account and a new **empty repository**.
2. Upload the contents of this folder to that repository (GitHub's web
   "Add file -> Upload files" works from a phone browser; upload the whole
   unzipped folder structure).
3. Open the **Actions** tab. The `Build APK` workflow runs automatically on
   push; if it doesn't, press **Run workflow**.
4. When it finishes (roughly 3-5 minutes), open the run and download the
   `websnap-widget-apk` artifact. It's a zip containing `app-debug.apk`.
5. Unzip on the phone, tap the APK, and allow installation from unknown
   sources when ColorOS prompts.

If you do have a computer, just open the folder in Android Studio and press Run.

## Adding the widget

Long-press an empty area of the home screen -> Widgets -> WebSnap Widget.
Drag it out, and the configuration screen opens.

| Setting | What it does |
|---|---|
| Page URL | The page to capture. `https://` is added if you omit it. |
| Zoom | Initial page scale, 25-400%. Lower values fit more content in. |
| Crop offset X / Y | Scrolls the page before capture, so you can frame a specific region rather than the top-left corner. |
| Refresh interval | Minutes between captures. 15 is the floor Android's scheduler will honour. |
| Desktop mode | Sends a desktop user-agent and widens the viewport. |

Tapping the widget opens the live page in your browser.

## ColorOS-specific notes

ColorOS is aggressive about background work, and a widget that stops refreshing
is almost always a battery-management issue rather than an app bug:

- Settings -> Battery -> **App battery usage** -> WebSnap Widget -> set to
  **Allow background activity** / **Unrestricted**.
- Settings -> Apps -> WebSnap Widget -> Battery -> disable **Sleep standby
  optimisation** if present.
- Add the app to the protected list in Recents (swipe up, tap the app's card
  menu, choose **Lock**).

Even with all that, Android's Doze mode can delay a scheduled capture past its
interval when the screen has been off a long time. That's expected behaviour,
not a failure.

## Foldable behaviour

Opening or closing the Find N5 changes the widget's cell dimensions, which fires
`onAppWidgetOptionsChanged`. The provider responds by re-capturing at the new
size, so the snapshot is re-rendered rather than stretched. Expect a brief
moment showing the old image while the new capture runs.

## Design constraints worth knowing

- **Snapshots, not live pages.** Android widgets can't host a WebView; only a
  fixed set of view types survive the RemoteViews boundary. Every app in this
  category, including the original Widgetify, works by screenshotting a page
  offscreen and shipping the bitmap. Interactive content won't be interactive.
- **~1MB bitmap ceiling.** RemoteViews cross a Binder transaction with a hard
  size limit, so large widgets are downscaled before being sent. Very large
  widgets will look slightly soft.
- **Login-gated pages.** The offscreen WebView keeps its own cookie jar, so
  pages behind a login generally won't render. Public pages and
  publicly-shareable dashboard links work best.
- **Battery.** Each capture spins up a full WebView and loads a page. Short
  intervals across several widgets add up quickly. 30 minutes is a sane default.

## Off-the-shelf alternative

If you'd rather not build anything: the original **Widgetify** by Binary-Smith
(`com.binarysmith.webclipwidget.ad`) does all of this and more — click-macro
replay for content behind interactions, change notifications, custom JavaScript
before capture, and capture conditions based on battery and network. It's
ad-supported. **WebsiteWidget** and **AnyWidget** on the Play Store are newer,
simpler options in the same space.

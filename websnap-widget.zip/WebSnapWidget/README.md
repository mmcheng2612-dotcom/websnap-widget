# WebSnap Widget

A Widgetify-style Android home-screen widget: point it at a URL, and it renders
a live snapshot of that page onto your home screen, refreshing on a schedule.
Built and tested against the Oppo Find N5 (ColorOS 15 / Android 15), including
its fold/unfold resize behaviour.

## Getting an installable APK without a PC

1. Create a free GitHub account and a new **empty repository**.
2. Upload the contents of this folder to that repository (GitHub's web
   "Add file -> Upload files" works from a phone browser; upload the whole
   unzipped folder structure).
3. Open the **Actions** tab. The `Build APK` workflow runs automatically on
   push; if it doesn't, press **Run workflow**.
4. When it finishes (roughly 3-5 minutes), open the run and download the
   `websnap-widget-apk` artifact. It's a zip containing `app-debug.apk`.
5. Unzip on the phone, tap the APK, and allow installation from unknown
   sources when ColorOS prompts.

If you do have a computer, just open the folder in Android Studio and press Run.

## Adding the widget

Long-press an empty area of the home screen -> Widgets -> WebSnap Widget.
Drag it out, and the configuration screen opens.

| Setting | What it does |
|---|---|
| Page URL | The page to capture. `https://` is added if you omit it. |
| Zoom | Initial page scale, 25-400%. Lower values fit more content in. |
| Crop offset X / Y | Scrolls the page before capture, so you can frame a specific region rather than the top-left corner. |
| Refresh interval | Minutes between captures. 15 is the floor Android's scheduler will honour. |
| Desktop mode | Sends a desktop user-agent and widens the viewport. |

Tapping the widget opens the live page in your browser.

## Signing in to a site that needs a login

Open the **WebSnap Widget** app from your app drawer (or tap **Sign in to this
site** in a widget's config screen). Type the URL, tap Go, and sign in exactly
as you would in Chrome. Tap **Done**.

The site's session cookie is stored in Android's standard WebView cookie jar,
which the offscreen capture WebView shares — so from then on, captures are made
as the logged-in you. This app never sees, stores, or transmits your password;
it only holds whatever cookie the site itself sets.

**Clear session** wipes all cookies, cached pages and web storage held by the
app. Use it before handing the phone to anyone, or if you stop using a site.

Two things that commonly break this:

- **User-agent mismatch.** Sessions are often bound to the browser identity that
  created them. The login window and the capture both send the same desktop
  user agent for this reason. Don't change one without the other.
- **Device or machine registration.** Some systems bind a session to a
  registered machine, not just a cookie. If a site asks you to register the
  computer or enrol the device, the widget's WebView counts as a new, separate
  machine — and only whoever administers that system can authorise it. No app
  can work around this, and trying to is usually a breach of the system's terms.

## Privacy mode

On by default. A privacy-mode widget shows a blank padlock tile and **does not
fetch the page at all** while hidden — nothing sensitive is rendered, cached, or
handed to the launcher. Tapping reveals the live capture for two minutes, then
it blanks itself again.

Turn it off only for pages you'd be comfortable showing a stranger, because a
normal widget's snapshot is visible on the home screen, in the recent-apps
preview, and to anyone glancing at the phone.

**If you point this at anything containing patient information**, that data is
leaving your organisation's controls and landing on a personal device. In
Singapore that engages the PDPA, and most clinical systems' terms of use forbid
it outright. Check with whoever owns the system before you do it — and prefer a
calendar feed (below) if one exists.

## Better option for calendars: subscribe to an ICS feed

Many clinical and scheduling systems can publish a private iCal/ICS URL. If
yours does, subscribe to it in your phone's calendar app instead of screenshotting
the web UI. You get a native calendar widget, proper encryption at rest, working
notifications, and no scraping — for far less effort than this app. Ask your
system administrator whether a feed is available before building around WebSnap.

## ColorOS-specific notes

ColorOS is aggressive about background work, and a widget that stops refreshing
is almost always a battery-management issue rather than an app bug:

- Settings -> Battery -> **App battery usage** -> WebSnap Widget -> set to
  **Allow background activity** / **Unrestricted**.
- Settings -> Apps -> WebSnap Widget -> Battery -> disable **Sleep standby
  optimisation** if present.
- Add the app to the protected list in Recents (swipe up, tap the app's card
  menu, choose **Lock**).

Even with all that, Android's Doze mode can delay a scheduled capture past its
interval when the screen has been off a long time. That's expected behaviour,
not a failure.

## Foldable behaviour

Opening or closing the Find N5 changes the widget's cell dimensions, which fires
`onAppWidgetOptionsChanged`. The provider responds by re-capturing at the new
size, so the snapshot is re-rendered rather than stretched. Expect a brief
moment showing the old image while the new capture runs.

## Design constraints worth knowing

- **Snapshots, not live pages.** Android widgets can't host a WebView; only a
  fixed set of view types survive the RemoteViews boundary. Every app in this
  category, including the original Widgetify, works by screenshotting a page
  offscreen and shipping the bitmap. Interactive content won't be interactive.
- **~1MB bitmap ceiling.** RemoteViews cross a Binder transaction with a hard
  size limit, so large widgets are downscaled before being sent. Very large
  widgets will look slightly soft.
- **Login-gated pages.** The offscreen WebView keeps its own cookie jar, so
  pages behind a login generally won't render. Public pages and
  publicly-shareable dashboard links work best.
- **Battery.** Each capture spins up a full WebView and loads a page. Short
  intervals across several widgets add up quickly. 30 minutes is a sane default.

## Off-the-shelf alternative

If you'd rather not build anything: the original **Widgetify** by Binary-Smith
(`com.binarysmith.webclipwidget.ad`) does all of this and more — click-macro
replay for content behind interactions, change notifications, custom JavaScript
before capture, and capture conditions based on battery and network. It's
ad-supported. **WebsiteWidget** and **AnyWidget** on the Play Store are newer,
simpler options in the same space.
